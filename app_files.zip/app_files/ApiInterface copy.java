package com.noticripto.rest;

//import android.telecom.Call;

//import com.noticripto.model.CriptoInfoModel;
import com.noticripto.database.Coins;
import com.noticripto.model.HomePageModel;
import com.noticripto.model.OurYtModel;
import com.noticripto.model.YtModel;
import com.noticripto.retrofit.CryptoList;

import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface ApiInterface {
    //retrofit interface
    //JSON --> GSON library --> Java Objects



    @Headers("X-CMC_PRO_API_KEY: 00000000000000000000000000000")
    @GET("/v1/cryptocurrency/listings/latest")
    Call<List<Coins>> doGetUserListAll(@QueryMap Map<String, String> params);


    The one that i used before
    // @Headers("X-CMC_PRO_API_KEY: 00000000000000000000000000000")
    // @GET("/v1/cryptocurrency/listings/latest")
    // Call<CriptoList> doGetUserListAll(@QueryMap Map<String, String> params);

}
