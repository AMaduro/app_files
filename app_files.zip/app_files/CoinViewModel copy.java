package com.noticripto.model;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.noticripto.database.CoinRepository;
import com.noticripto.database.Coins;

public class CoinViewModel extends AndroidViewModel {
    private CoinRepository repository;

    public CoinViewModel(@NonNull Application application) {
        super(application);
        repository = new CoinRepository(application);
    }

    public void getCoins(boolean reload, CoinRepository.DataReadyListener listener) {
        repository.getCoins(reload, listener);
    }

    public LiveData<Coins> getCoin(int id) {
        return repository.getCoin(id);
    }
}