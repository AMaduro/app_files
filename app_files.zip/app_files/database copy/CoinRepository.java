package com.noticripto.database;

import android.app.Application;
import android.util.Log;

import androidx.lifecycle.LiveData;

import com.noticripto.APIClientCoin;
import com.noticripto.rest.ApiInterface;
import com.noticripto.retrofit.CryptoList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CoinRepository {
    private static final String TAG = "Repo/Coin";


    private final CoinDao coinDao;
    private final LiveData<List<Coins>> coins;
    Integer posts = 500;

    public CoinRepository(Application application) {
        coinDao = AppDatabase.getInstance(application).coinDao();
        coins = coinDao.getAll();

        Log.d(TAG, "New instance created...");
    }

    /*
        I've added boolean flag to check if data reload from Web API is compulsory.
        You can remove this flag and modify it as per your logic.

        DataReadyListener is a callback listener.
        Its onDataReady() method gets fired when data is ready.
    */
    public void getCoins(boolean reload, DataReadyListener listener) {
        if(reload){
            //Modify this portion as per your logic
            ApiInterface apiInterfaceCoin5 =
                    APIClientCoin.getClient().create(ApiInterface.class);
            Map<String, String> params = new HashMap<>();
            params.put("limit", posts+"");

            Call<List<Coins>> call = apiInterfaceCoin5.doGetUserListAll(params);

             call.enqueue(new Callback<List<Coins>> () {
                        @Override
                        public void onResponse(Call<List<Coins>>  call, Response<List<Coins>> response) {

                            Future<?> future = AppDatabase.databaseWriteExecutor.submit(() -> {
                                coinDao.deleteAll(); //remove this if you want to keep previous data
                                coinDao.insertAll(response.body());

                                Log.d(TAG, "Data inserted in \"coins\" table");
                            });

                            try {
                                future.get();
                                if (future.isDone())
                                    listener.onDataReady(coins);
                            } catch (ExecutionException e) {
                                e.printStackTrace();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onFailure(Call<List<Coins>>  call, Throwable t) {
                            //Handle failure here
                        }
                    });
        }
        else{
            listener.onDataReady(coins);
        }
    }

    public LiveData<Coins> getCoin(int id) {
        return coinDao.get(id);
    }

    public interface DataReadyListener {
        void onDataReady(LiveData<List<Coins>> coins);
    }
}