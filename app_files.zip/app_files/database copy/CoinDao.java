package com.noticripto.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
    public interface CoinDao {
        @Query("SELECT * FROM coin_table")
        LiveData<List<Coins>> getAll();

        @Query("SELECT * FROM coin_table WHERE id = :id")
        LiveData<Coins> get(int id);

//        @Query("SELECT * FROM coin_table WHERE id IN (:userIds)")
//        List<Coins loadAllByIds(int[] userIds);
//
//        @Query("SELECT * FROM coin_table WHERE name LIKE :first AND " +
//                "last_name LIKE :last LIMIT 1")

        //Coins findByName(String first, String last);

        @Insert
        void insertAll(List<Coins> coins);

        @Query("DELETE FROM coin_table")
        void deleteAll();

        @Update
        public void update(Coins coin);
    }


