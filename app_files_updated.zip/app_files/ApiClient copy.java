package com.noticripto.rest;

import androidx.appcompat.app.AppCompatActivity;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ApiClient extends AppCompatActivity {


    public static final String BASE_URL = "http://10.0.2.2:8888/newsapp/wp-json/api/";

    //For real devices users
    //1- connect your laptop and mobile on the same wifi
    //2 - find local ip address of your laptop
    //3 - add that local ip address in your BASE_URL
    //You need to update this ip address everytime your pc is connected to the internet
    public static final String BASE_URL_REAL = "https://www.coinvarmarket.com/wp-json/api/";
    //public static final String BASE_URL_REAL = "http://10.0.0.195:8888/newsapp/wp-json/api/";
    //wp-json/wp/v2/posts


    //public static final String BASE_URL_REAL = "http://192.168.1.170:8888/newsapp/wp-json/api/";

    //192.168.1.170



    //Getting the retrofit api client
    private static Retrofit retrofit = null;

    private static Retrofit retrofit2 = null;

    public static Retrofit getApiClient(){

        HttpLoggingInterceptor loggingInterceptor = new HttpLoggingInterceptor();
        loggingInterceptor.level(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .build();

        if (retrofit == null){
            retrofit = new Retrofit.Builder().baseUrl(BASE_URL_REAL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

        }

        return retrofit;

    }








}












