package com.noticripto.database;


import android.content.Context;
import android.util.Log;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Coins.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    private static final String TAG = "DB";

    // DB INFO
    private static final String databaseName = "coin_database";

    // DAOs
    public abstract CoinDao coinDao();


    // INSTANCE
    private static volatile AppDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static AppDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), AppDatabase.class, databaseName)
                            .build();
                    Log.d(TAG, "New instance created...");
                }
            }
        }
        return INSTANCE;
    }
}
