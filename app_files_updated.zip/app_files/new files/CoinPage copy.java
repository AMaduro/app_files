package com.noticripto;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.noticripto.adapters.CryptoListAllCoinAdapter;
//import com.noticripto.model.CriptoInfoModel;
import com.noticripto.rest.ApiClientInfoCoin;
import com.noticripto.rest.ApiInterface;
import com.noticripto.retrofit.CryptoList;
import com.noticripto.retrofit.Datum;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CoinPage extends AppCompatActivity {

    Context context;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coin_page);


        Intent intent = getIntent();
        Datum datum = (Datum) intent.getSerializableExtra("coin");


        getCurrencyData(datum.getId());

        TextView name = findViewById(R.id.name);
        TextView price = findViewById(R.id.price);
        TextView date = findViewById(R.id.date);
        TextView clasificacionRank = findViewById(R.id.clasificacionRank);
        //TextView symbol = findViewById(R.id.symbol);
        TextView slug = findViewById(R.id.slug);
        TextView volume24h = findViewById(R.id.volume24h);
        TextView circulating_supply = findViewById(R.id.circulating_supply);
        TextView max_supply = findViewById(R.id.max_supply);
        TextView market_cap = findViewById(R.id.market_cap);
        ImageView coin_icon = (ImageView) findViewById(R.id.coin_icon);

        TextView titleName = findViewById(R.id.titleName);


        // TextView change1h = findViewById(R.id.change1h);
        TextView change24h = findViewById(R.id.change24h);
        //TextView change7d = findViewById(R.id.change7d);


        clasificacionRank.setText("#" + datum.getCmcRank());

        name.setText(datum.getName() + " (" + datum.getSymbol() + ")");
        date.setText("Última actualización: " + parseDateToddMMyyyy(datum.getLastUpdated()));

        titleName.setText(datum.getName());

        //symbol.setText("Symbol: " + datum.getSymbol());
        slug.setText(datum.getSlug());
        volume24h.setText("$" + String.format("%,d", Math.round(datum.getQuote().getUSD().getVolume24h())));

        circulating_supply.setText(String.format("%.0f", datum.getCirculatingSupply()));


        if(datum.getQuote().getUSD().getPrice() >= 1){

            price.setText("$" + String.format("%,.2f", datum.getQuote().getUSD().getPrice()));

        }else{

            price.setText("$" + String.format("%,.9f", datum.getQuote().getUSD().getPrice()));

        }


        if(datum.getQuote().getUSD().getPercentChange24h() < 0.000){
            //red

            change24h.setBackgroundColor(getResources().getColor(R.color.red));


        }else{
            //green
            change24h.setBackgroundColor(getResources().getColor(R.color.green));
        }





        if(datum.getMaxSupply() == null){
            max_supply.setText("No hay datos");
        }else{
            max_supply.setText(String.format("%.0f", datum.getMaxSupply()));

        }

        System.out.println("Max sup  = " + datum.getMaxSupply());


        market_cap.setText("$" + String.format("%,d", Math.round(datum.getQuote().getUSD().getMarketCap())));

        //change1h.setText(String.format("Change 1h: %.2f", datum.getQuote().getUSD().getPercentChange1h()) + "%");
        change24h.setText(String.format("%.2f", datum.getQuote().getUSD().getPercentChange24h()) + "%");
        //change7d.setText(String.format("Change 7d: %.2f", datum.getQuote().getUSD().getPercentChange7d()) + "%");


        //load coin icon
        //if the link doesn't work then you have to upload it into your own server
        Glide.with(this)
                .load(new StringBuilder("https://s2.coinmarketcap.com/static/img/coins/64x64/")
                        .append(datum.getId())
                        .append(".png").toString())
                .placeholder(R.drawable.money_icon)
                .into(coin_icon);


    }



    private String parseDateToddMMyyyy(String time) {
        //parse the server timestamp. Make sure it is in UTC timezone as per API specifications.
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault());
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));

        //format the utc server timestamp to local timezone.
        SimpleDateFormat output = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault());
        output.setTimeZone(TimeZone.getDefault());

        Date date = null;
        try {
            date = sdf.parse(time);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return output.format(date);
    }





    private String getCurrencyData(Integer coinId){

        String url = "https://pro-api.coinmarketcap.com/v1/cryptocurrency/info?id=" + coinId;


        String coinDesc = null;

        System.out.println("Inside getCurrencyData coinID " + coinId);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new com.android.volley.Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

               // loadingPB.setVisibility(View.GONE);

                try {
                    JSONArray dataArray = response.getJSONArray("data");

                    System.out.println(" DataObj = " + dataArray.toString());

                    for (int i=0; i<dataArray.length();i++){

                        JSONObject dataObj = dataArray.getJSONObject(i);

//                        String name = dataObj.getString("name");
//                        String symbolName = dataObj.getString("symbol");
//                        int id = dataObj.getInt("id");
//                        JSONObject quote = dataObj.getJSONObject("quote");
//                        JSONObject USD = quote.getJSONObject("USD");
//                        double price = USD.getDouble("price");
//                        int marketCap = USD.getInt("market_cap");
//                        double textView24h = USD.getDouble("percent_change_24h");

                       // currencyRVModalArrayList.add(new CurrencyRVModal(name,symbolName,price,marketCap,textView24h, id));
                    }

                   // currencyRVAdapter.notifyDataSetChanged();

                }catch(JSONException e){

                    e.printStackTrace();

                }
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(CoinPage.this,"Fail to get data...", Toast.LENGTH_SHORT).show();
            }
        }){

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("X-CMC_PRO_API_KEY","c8da3925-fdc5-47ce-a890-7d84a654f4cb");
                return headers;
            }
        };

        requestQueue.add(jsonObjectRequest);
        return coinDesc;

    }




}
