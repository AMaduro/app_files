package com.noticripto.model;

public class CurrencyRVModal {

    private String name;
    private String symbol;
    private double price;
    private int market_cap;
    private double percent_change_24h;
    private int id;

    public CurrencyRVModal(String name, String symbol, double price, int market_cap, double percent_change_24h, int id) {
        this.name = name;
        this.symbol = symbol;
        this.price = price;
        this.market_cap = market_cap;
        this.percent_change_24h = percent_change_24h;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getMarketCap() {
        return market_cap;
    }

    public void setMarketCap(int market_cap) {
        this.market_cap = market_cap;
    }


    public double getPercentChange24h() {
        return percent_change_24h;
    }

    public void setPercentChange24h(double percent_change_24h) {
        this.percent_change_24h = percent_change_24h;
    }


    public int getId() {
        return id;
    }

    public void SetId(int id) {
        this.id = id;
    }
}
