package com.noticripto.activities;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.noticripto.APIClientCoin;
import com.noticripto.CoinPage;
import com.noticripto.MainActivity;
import com.noticripto.R;
//import com.noticripto.model.CriptoInfoModel;
import com.noticripto.adapters.CryptoListAllCoinAdapter;
import com.noticripto.adapters.CurrencyRVAdapter;
import com.noticripto.database.CoinRepository;
import com.noticripto.database.Coins;
import com.noticripto.model.CoinViewModel;
import com.noticripto.model.CurrencyRVModal;
import com.noticripto.rest.ApiInterface;
import com.noticripto.retrofit.CryptoList;
import com.noticripto.retrofit.Datum;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CryptoListAllCoinActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {

    //we will load real news from our website
    RecyclerView recyclerView4;


    //variables for making infinite news feed
    int page = 1;
    int posts = 500;
    boolean isFromStart = true;

    //progressBar
    ProgressBar progressBar3;

    ShimmerFrameLayout shimmerFrameLayout;

    NestedScrollView nestedScrollView5;

    SwipeRefreshLayout swipeRefreshLayout5;

    //List<CriptoInfoModel._1> coinDescription;

    CryptoListAllCoinAdapter adapterCoin5;

//    CryptoListAllCoinAdapter currencyRVAdapter;
   // CurrencyRVAdapter currencyRVAdapter;
    ApiInterface apiInterfaceCoin5;
    List<Datum> cryptoList5 = null;



    EditText searchView;
    CharSequence search="";

    Toolbar toolbar;

    BottomNavigationView bottomNavigationView;

    Context context;

    //new
    private ArrayList<CurrencyRVModal> currencyRVModalArrayList;
    //private CurrencyRVAdapter currencyRVAdapter;

    private CoinViewModel coinViewModel;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crypto_list_all_coin);

        coinViewModel = new ViewModelProvider(this).get(CoinViewModel.class);



//        System.out.println("coinDescription Size = "+coinDescription.size());

        bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.page_3);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {


                switch (item.getItemId()){

                    case R.id.page_1:
                        startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        overridePendingTransition(0,0);
                        return true;

                    case R.id.page_2:
                        startActivity(new Intent(getApplicationContext(),YoutubeActivity.class));
                        overridePendingTransition(0,0);

                        return true;

                    case R.id.page_3:

                        return true;



                }

                return false;
            }
        });


        apiInterfaceCoin5 = APIClientCoin.getClient().create(ApiInterface.class);

        toolbar = findViewById(R.id.myToolBar);
        setSupportActionBar(toolbar); //NO PROBLEM !!!!
        toolbar.setTitle("CRIPTOMONEDAS");
        toolbar.getForegroundGravity();


        InitiateViews();


        searchView = findViewById(R.id.search_bar);

        page =1;
        isFromStart = true;


        SearchView search = (SearchView) findViewById(R.id.search);
        search.setActivated(true);
        search.setQueryHint("Buscar...");
        search.onActionViewExpanded();
        search.setIconified(false);
        search.clearFocus();

//
        search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                adapterCoin5.getFilter().filter(newText);

                return false;
            }
        });

    }


    @SuppressLint("ResourceAsColor")
    private void InitiateViews() {


        // Initialize data
        cryptoList5 = new ArrayList<>();


        // Create adapter passing in the sample user data
        adapterCoin5 = new CryptoListAllCoinAdapter(cryptoList5);


        coinViewModel.getCoins(false, new CoinRepository.DataReadyListener() {
            @Override
            public void onDataReady(LiveData<List<Coins>> coins) {
                //Add or set data in adapter
                //for setData() you need to create setData() method in adapter
                //which first clears existing data and then adds new data to list and notifies about dataset change.
                coins.observe(CryptoListAllCoinActivity.this, coinsList -> adapterCoin5.setData(coinsList));
            }
        });


        progressBar3 = findViewById(R.id.progressBar);

        shimmerFrameLayout = findViewById(R.id.shimmerFrameLayout);
        shimmerFrameLayout.setVisibility(View.VISIBLE);
        shimmerFrameLayout.startShimmer();


        nestedScrollView5 = findViewById(R.id.nested2);

        recyclerView4 = findViewById(R.id.my_recycler_view_coin);
        LinearLayoutManager linearLayoutManager3 =new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView4.setLayoutManager(linearLayoutManager3);
        recyclerView4.setNestedScrollingEnabled(false);
        recyclerView4.setAdapter(adapterCoin5);


        swipeRefreshLayout5 = findViewById(R.id.swipy);
        swipeRefreshLayout5.setRefreshing(true);
        swipeRefreshLayout5.setColorSchemeColors(R.color.yellow,R.color.black, R.color.white);


//        adapterCoin5.setClickListener(new CryptoListAllCoinAdapter.ItemClickListener() {

        adapterCoin5.setClickListener(new CryptoListAllCoinAdapter.ItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {

                //Toast.makeText(MainActivity.this, "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(CryptoListAllCoinActivity.this, CoinPage.class);
                intent.putExtra("coin", adapterCoin5.getItem(position));
                startActivity(intent);

            }
        });

        swipeRefreshLayout5.setOnRefreshListener(this);

    }

    @Override
    protected void onStop() {

        super.onStop();
        //sliderLayout.stopAutoCycle();
    }


    @Override
    public void onRefresh() {

        isFromStart = true;
        posts = 10;
        page = 1;
        //getCoinList();

    }


//    public void getCoinList() {
//
//        //posts = 500
//        ApiInterface apiInterfaceCoin5 = APIClientCoin.getClient().create(ApiInterface.class);
//        Map<String, String> params = new HashMap<>();
//        params.put("limit", posts+"");
//
//      Call<CryptoList> call5 = apiInterfaceCoin5.doGetUserListAll(params);
//
//
//
//        call5.enqueue(new Callback<CryptoList>() {
//            @Override
//            public void onResponse(Call<CryptoList> call, Response<CryptoList> response) {
//
//                shimmerFrameLayout.stopShimmer();
//                shimmerFrameLayout.setVisibility(View.GONE);
//                swipeRefreshLayout5.setRefreshing(false);
//
//                int beforeCoinSize = cryptoList5.size();
//
//                CryptoList list5 = response.body();
//
//
//                cryptoList5.addAll(list5.getData());
//
//                recyclerView4.setAdapter(adapterCoin5);
//
//            }
//
//            @Override
//            public void onFailure(Call<CryptoList> call, Throwable t) {
//                //Toast.makeText(CryptoListAllCoinActivity.this, "onFailure", Toast.LENGTH_SHORT).show();
//              //  Log.d("XXXX", t.getLocalizedMessage());
//                call.cancel();
//                progressBar3.setVisibility(View.GONE);
//                shimmerFrameLayout.setVisibility(View.GONE);
//                swipeRefreshLayout5.setRefreshing(false);
//            }
//        });
//    }



//    public void getCoinInfo() {
//
////        ApiInterface apiInterfaceCoin5 = APIClientCoin.getClient().create(ApiInterface.class);
////        Map<String, String> params = new HashMap<>();
////        params.put("limit", posts+"");
////
////      Call<CryptoList> call5 = apiInterfaceCoin5.doGetUserListAll(params);
//
//        Call<CryptoList> call5 = apiInterfaceCoin5.doGetUserList("2000");
//
//        call5.enqueue(new Callback<CryptoList>() {
//            @Override
//            public void onResponse(Call<CryptoList> call, Response<CryptoList> response) {
//                progressBar3.setVisibility(View.GONE);
//                swipeRefreshLayout5.setRefreshing(false);
//
//                int beforeCoinSize = cryptoList5.size();
//
//                CryptoList list5 = response.body();
//
//                // do not reinitialize an existing reference used by an adapter
//                // add to the existing list
//
//                if(isFromStart){
//
//                    //refresh crypto price
//                    cryptoList5.clear();
//                }
////
//                cryptoList5.addAll(list5.getData());
//
//                if(isFromStart){
//                    recyclerView4.setAdapter(adapterCoin5);
//
//                }else{
//                    adapterCoin5.notifyItemRangeInserted(beforeCoinSize, list5.getData().size());
//
//                }
//
//
////                for(int i = 0; i < list5.getData().size(); i++){
////
////                    cryptoList5.addAll(list5.getData());
////
////                }
//
//                //remove to add categories
//                //categoryBottons.addAll(body.getCategoryBotton());
//
//                if(isFromStart){
//                    recyclerView4.setAdapter(adapterCoin5);
//
//                }else{
//                    adapterCoin5.notifyItemRangeInserted(beforeCoinSize, list5.getData().size());
//                    // adapterCoin.notifyDataSetChanged();
//
//                }
//
//
////                cryptoList.clear();
//            }
//
//            @Override
//            public void onFailure(Call<CryptoList> call, Throwable t) {
//                Toast.makeText(CryptoListAllCoinActivity.this, "onFailure", Toast.LENGTH_SHORT).show();
//                Log.d("XXXX", t.getLocalizedMessage());
//                call.cancel();
//                progressBar3.setVisibility(View.GONE);
//                swipeRefreshLayout5.setRefreshing(false);
//            }
//        });
//    }



}